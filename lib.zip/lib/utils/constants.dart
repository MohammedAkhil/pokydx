String baseHappinessDescription = """
    A Pokémon's base friendship is the value to which its friendship
     is set when the Pokémon is caught, received from an event or NPC, or
      received from a trade with another player. If a Pokémon is caught in a Friend Ball,
       however, it will always start out with 200 friendship. If a Pokémon hatched from an Egg,
        it will start with 120 friendship.
    """;
